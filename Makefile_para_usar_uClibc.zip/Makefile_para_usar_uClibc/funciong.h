//funciong.h
#ifndef FUNCIONG_H
#define FUNCIONG_H
char g(unsigned int);
#endif /*FUNCIONG_H*/
