//Archivo hello.c
//#include <funciong.h>
#include <funciong.h>
#include <stdio.h>
int atoi (const char *);

int main(int argc, char *argv[])
{
	int intA;
#ifdef TEST1
	printf("%c\n",g(29%7));
#endif
	if(argc>2){
		printf("FORMA DE USO:%s <n><--|\n",argv[0]);
		return 1;
	}
	intA=atoi(argv[1]);
	printf("%i\n",intA);
	for(intA=0;intA<argc;++intA)
	{
		printf("%5i%20s\n",intA,argv[intA]);
	}
	return 0;
}

