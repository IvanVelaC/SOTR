/**hola.c**/
#include <stdio.h>

int main(){
 printf("Hola mundo C:\n");
 return 20;
}

