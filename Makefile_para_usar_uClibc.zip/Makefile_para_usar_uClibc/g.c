//Archivo g.c
char D[]={
	'm', /*martes*/
	'M', /*Miercoles*/
	'j', /*jueves*/
	'v', /*viernes*/
	's', /*sabado*/
	'd', /*domingo*/
	'L', /*lunes*/ 

};

char g(unsigned int n)
{
	if(n>6)
		return ' ';
	return D[n];
}
